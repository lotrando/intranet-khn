
-- --------------------------------------------------------

--
-- Struktura tabulky `departments`
--

CREATE TABLE `departments` (
  `id` bigint UNSIGNED NOT NULL,
  `department_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `center_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `department_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Vypisuji data pro tabulku `departments`
--

INSERT INTO `departments` (`id`, `department_code`, `center_code`, `color_id`, `department_name`) VALUES
(1, '401', '4501', 'blue', 'Interní oddělení'),
(2, '402', '4502', 'azure', 'Endokrinologická ambulance'),
(3, '403', '4503', 'azure', 'Příjmová interní ambulance'),
(4, '404', '4507', 'azure', 'Gastroenterologická ambulance'),
(5, '405', '4507', 'azure', 'Interní odborné ambulance'),
(6, '407', '4512', 'purple', 'Neurologické oddělení'),
(7, '408', '4513', 'purple', 'Neurologická ambulance'),
(8, '410', '4501', 'lime', 'Odělení chirurgie páteře'),
(9, '411', '4521', 'lime', 'JIP oddělení chirurgie páteře a ortopedie'),
(10, '412', '4524', 'lime', 'Ambulance chirurgie páteře'),
(11, '413', '4551', 'green', 'Rehabilitační oddělení'),
(12, '414', '4552', 'green', 'Rehabilitační ambulance'),
(13, '415', '4558', 'cyan', 'Oddělení pracovního lékařství'),
(14, '417', '4547', 'pink', 'OKB'),
(15, '418', '4549', 'red', 'RDG'),
(16, '419', '4522', 'lime', 'Operační sály'),
(17, '420', '4110', 'yellow', 'Ředitelství'),
(18, '421', '4120', 'orange', 'Stravovací provoz - kantýna'),
(19, '422', '4130', 'muted', 'Úklid'),
(20, '424', '4528', 'lime', 'Anesteziologická ambulance'),
(21, '425', '4504', 'azure', 'Diabetologická ambulance'),
(22, '426', '4141', 'teal', 'Lékárna KHN'),
(23, '427', '4510', 'indigo', 'Mezioborová JIP'),
(24, '428', '4524', 'muted', 'Provozní úsek'),
(25, '429', '4150', 'muted', 'Údržba'),
(26, '432', '4507', 'azure', 'Ambulance infuzní terapie'),
(27, '433', '4524', 'lime', 'Mamologická poradna'),
(28, '434', '4525', 'orange', 'Ortopedické oddělení'),
(29, '436', '4143', 'teal', 'Lékárna KHN v Ráji'),
(30, '437', '4560', 'orange', 'Oddělení následné péče'),
(31, '999', '9999', 'muted', 'Externí pracovník');
