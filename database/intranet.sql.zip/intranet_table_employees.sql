
-- --------------------------------------------------------

--
-- Struktura tabulky `employees`
--

CREATE TABLE `employees` (
  `id` bigint UNSIGNED NOT NULL,
  `personal_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_preffix` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `middle_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `married_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_suffix` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `department_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `job_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_card` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `coffee` enum('A','N') COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `employment` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` int DEFAULT NULL,
  `status` enum('Aktivní','Neaktivní','Mateřská') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Neaktivní',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Vypisuji data pro tabulku `employees`
--

INSERT INTO `employees` (`id`, `personal_number`, `image`, `title_preffix`, `last_name`, `middle_name`, `married_name`, `first_name`, `title_suffix`, `department_id`, `job_id`, `email`, `start_date`, `end_date`, `comment`, `phone`, `mobile`, `id_card`, `coffee`, `employment`, `position`, `status`, `created_at`, `updated_at`) VALUES
(1, '64150', '64150.jpg', 'Ing.', 'Macháček', NULL, NULL, 'Emil', 'Dr.', '30', '7', 'radka08@example.net', '2023-01-06', '2023-01-17', 'Quam eligendi fugiat possimus soluta aspernatur vitae iste. Quidem qui aliquid aut in nostrum animi facere. Error quam quia quae ex et autem. Ad ipsa omnis eos officiis repudiandae.', '360', '+22208409662', 'Předat nálepku', 'N', 'EVP', NULL, 'Aktivní', '2023-01-11 16:48:16', '2023-01-11 16:48:16'),
(2, '64011', '64011.jpg', 'MVDr.', 'Farkaš', NULL, NULL, 'Zdeňka', 'Mgr.', '21', '30', 'hsimackova@example.com', '2023-01-10', '2023-01-18', 'Vitae dolores ea quasi impedit aliquid temporibus. Veniam voluptatem non consequatur aut aliquam quis.', '432', '+9715750864090', 'Vytvořit kartu', 'A', 'DPP', NULL, 'Neaktivní', '2023-01-11 16:48:16', '2023-01-11 16:48:16'),
(3, '62224', '62224.jpg', 'RNDr.', 'Duda', NULL, NULL, 'Renata', 'doc.', '1', '40', 'volny.lukas@example.org', '2023-01-18', '2023-01-04', 'Ut itaque a expedita adipisci veritatis. Quo non iusto aperiam. Architecto architecto quis fugiat sequi dolor facilis. Ullam officiis saepe tempore vel aperiam voluptas beatae autem.', '400', '+377236921469', 'Vytvořit kartu', 'N', 'DPP', NULL, 'Mateřská', '2023-01-11 16:48:16', '2023-01-11 16:48:16'),
(4, '61216', '61216.jpg', 'PhDr.', 'Junek', NULL, NULL, 'Karolína', 'JUDr.', '3', '59', 'uhartmanova@example.com', '2023-01-17', '2023-01-08', 'Aperiam minima natus et id et aut aut. Voluptatem voluptates consequatur rerum quis quis expedita similique. Ullam ut aut dolorum quo saepe eius et nobis.', '380', '+6906405907', 'Vytvořit kartu', 'N', 'EVP', NULL, 'Mateřská', '2023-01-11 16:48:16', '2023-01-11 16:48:16'),
(5, '61446', '61446.jpg', 'PhDr.', 'Sommer', NULL, NULL, 'Aneta', 'MUDr.', '14', '59', 'kuchtova.vladislav@example.org', '2023-01-08', '2023-01-17', 'Ea labore fuga beatae consequatur error ut beatae. Excepturi fugiat nihil sapiente ducimus ad.', '405', '+24105690575', 'Vytvořit kartu', 'N', 'HPP', NULL, 'Aktivní', '2023-01-11 16:48:16', '2023-01-11 16:48:16'),
(6, '62698', '62698.jpg', 'PhDr.', 'Nedvědová', NULL, NULL, 'Vojtěch', 'JUDr.', '5', '5', 'eholcova@example.net', '2023-01-14', '2023-01-08', 'Repellat occaecati totam ea ut. Quod voluptas nostrum nihil. Reiciendis qui facilis ad itaque aut aperiam enim. Explicabo ut fugiat corporis explicabo amet incidunt.', '442', '+987702297653', 'Předat nálepku', 'N', 'EVP', NULL, 'Mateřská', '2023-01-11 16:48:16', '2023-01-11 16:48:16'),
(7, '61267', '61267.jpg', 'MUDr.', 'Odehnal', NULL, NULL, 'Matyáš', 'MUDr.', '28', '49', 'vladimira.fuksova@example.org', '2023-01-11', '2023-01-04', 'Quae ea minima reprehenderit omnis magnam. Esse nihil dolor aliquid facilis. Eligendi aliquid iusto et totam. Et rerum aperiam in aliquid provident ipsam.', '483', '+33226996819', 'Předat nálepku', 'A', 'DPP', NULL, 'Mateřská', '2023-01-11 16:48:16', '2023-01-11 16:48:16'),
(8, '63487', '63487.jpg', 'PhDr.', 'Machala', NULL, NULL, 'Vladimír', 'JUDr.', '2', '34', 'libuse.binova@example.com', '2023-01-09', '2023-01-16', 'Et maiores eligendi perspiciatis hic repellat sed. Aut delectus et sint commodi voluptatem nam voluptas. Voluptas amet et id totam.', '400', '+6746097281', 'Nový nástup', 'N', 'ČSO', NULL, 'Aktivní', '2023-01-11 16:48:16', '2023-01-11 16:48:16'),
(9, '64092', '64092.jpg', 'MVDr.', 'Kopalová', NULL, NULL, 'Filip', 'MUDr.', '15', '5', 'jmuller@example.com', '2023-01-18', '2023-01-11', 'Architecto esse non rerum ut qui quo et. Eum inventore et est dicta ut voluptate. Tenetur voluptatem omnis ut assumenda inventore nobis dolorem in. Ut temporibus eos et nostrum excepturi.', '395', '+94132364053', 'Předat nálepku', 'N', 'HPP', NULL, 'Mateřská', '2023-01-11 16:48:16', '2023-01-11 16:48:16'),
(10, '62083', '62083.jpg', 'Ing.', 'Vančurová', NULL, NULL, 'Růžena', 'JUDr.', '29', '44', 'buriankova.kamil@example.com', '2023-01-09', '2023-01-15', 'Eaque aut eaque expedita pariatur. Animi reiciendis quia harum incidunt. Rerum consectetur reprehenderit consequuntur quos vitae ullam quia. Velit nam id quae illum distinctio sit dignissimos omnis.', '532', '+8557739562339', 'Předat nálepku', 'N', 'EVP', NULL, 'Neaktivní', '2023-01-11 16:48:16', '2023-01-11 16:48:16'),
(11, '63334', '63334.jpg', 'Mgr.', 'Janíček', NULL, NULL, 'Antonín', 'Bc.', '44', '57', 'kamila44@example.net', '2023-01-19', '2023-01-19', 'Hic sint incidunt et. In numquam debitis hic quo. Et praesentium quisquam voluptas commodi. Dolor repellat amet explicabo perferendis nisi dolores. Ad ut repellat provident nihil dolorum.', '432', '+3806473175890', 'Aktualizovat nálepku', 'N', 'DPP', NULL, 'Aktivní', '2023-01-13 16:56:56', '2023-01-13 16:56:56'),
(12, '64352', '64352.jpg', 'PhDr.', 'Vítek', NULL, NULL, 'Blanka', 'Dr.', '39', '55', 'antonin28@example.org', '2023-01-09', '2023-01-12', 'Non quo enim aut culpa omnis atque. Inventore et reprehenderit quia rem non recusandae.', '356', '+25747589260', 'Aktualizovat nálepku', 'N', 'EVP', NULL, 'Aktivní', '2023-01-13 16:56:56', '2023-01-13 16:56:56'),
(13, '62300', '62300.jpg', 'JUDr.', 'Kurková', NULL, NULL, 'Lubomír', 'Ing.', '59', '29', 'vmlejnkova@example.net', '2023-01-15', '2023-01-19', 'Voluptates repellendus sequi numquam architecto quisquam minus quia. Ea laborum enim ea.', '346', '+2483760491', 'Předat nálepku', 'A', 'HPP', NULL, 'Aktivní', '2023-01-13 16:56:56', '2023-01-13 16:56:56'),
(14, '62722', '62722.jpg', 'Dr.', 'Plšková', NULL, NULL, 'Aneta', 'Bc.', '17', '10', 'votrubova.josef@example.com', '2023-01-12', '2023-01-10', 'Harum fuga tempora vitae repellat itaque dicta beatae. Eos praesentium occaecati repellendus dicta perferendis in dolor provident. Ea numquam ea fuga voluptatem. Rerum eius et voluptates modi ut et.', '437', '+35779507636', 'Aktualizovat nálepku', 'A', 'DPP', NULL, 'Neaktivní', '2023-01-13 16:56:56', '2023-01-13 16:56:56'),
(15, '62765', '62765.jpg', 'Ing.', 'Kocmanová', NULL, NULL, 'Vlasta', 'doc.', '56', '134', 'zmirga@example.com', '2023-01-20', '2023-01-18', 'Consectetur sunt mollitia et. Ducimus dicta facilis ipsam id nesciunt. Itaque odit libero reiciendis autem alias non qui. Eum odit aliquam suscipit nesciunt quam.', '510', '+6764965753', 'Ok', 'N', 'DPP', NULL, 'Aktivní', '2023-01-13 16:56:56', '2023-01-13 16:56:56'),
(16, '64718', '64718.jpg', 'RNDr.', 'Motlová', NULL, NULL, 'Markéta', 'MVDr.', '31', '134', 'jitka72@example.com', '2023-01-20', '2023-01-10', 'Nostrum est eos eius vero sint minima. Quia expedita quisquam inventore voluptas numquam voluptas dolores labore. Et fuga est id sit atque est.', '538', '+445083006148', 'Nový nástup', 'N', 'DPČ', NULL, 'Neaktivní', '2023-01-13 16:56:56', '2023-01-13 16:56:56'),
(17, '62372', '62372.jpg', 'JUDr.', 'Hošková', NULL, NULL, 'Klára', 'MVDr.', '21', '20', 'anezka64@example.net', '2023-01-07', '2023-01-18', 'Iure magni qui doloremque dolorem earum. Voluptatem aut modi aut aliquam voluptas. In iusto ut similique nihil ducimus repellat maiores cum.', '487', '+668146143231', 'Nový nástup', 'A', 'ČSO', NULL, 'Mateřská', '2023-01-13 16:56:57', '2023-01-13 16:56:57'),
(18, '62383', '62383.jpg', 'Dr.', 'Mlejnková', NULL, NULL, 'Kristýna', 'Mgr.', '25', '44', 'novackova.ivana@example.com', '2023-01-20', '2023-01-07', 'Neque eum occaecati enim sunt. Qui consequatur vel earum fugit. Itaque mollitia omnis labore ipsa. Voluptate laboriosam itaque suscipit eos officiis enim.', '474', '+240498339741', 'Vytvořit kartu', 'A', 'DPČ', NULL, 'Neaktivní', '2023-01-13 16:56:57', '2023-01-13 16:56:57'),
(19, '61021', '61021.jpg', 'Bc.', 'Křenková', NULL, NULL, 'Miloslav', 'Dr.', '45', '18', 'sona.zelenkova@example.net', '2023-01-11', '2023-01-13', 'Exercitationem libero est neque eum. Itaque odio vero blanditiis illo libero nisi. Similique iure ea sed quibusdam ratione deleniti doloremque.', '420', '+420213426647', 'Předat nálepku', 'A', 'HPP', NULL, 'Mateřská', '2023-01-13 16:56:57', '2023-01-13 16:56:57'),
(20, '64887', '64887.jpg', 'doc.', 'Červeňáková', NULL, NULL, 'Olga', 'Bc.', '22', '107', 'miloslav83@example.com', '2023-01-19', '2023-01-20', 'Enim et accusantium beatae repudiandae et. Sed nostrum vero dolor accusamus. Est atque cum ex voluptas totam qui. Quia accusantium odit beatae hic vitae et.', '536', '+6839927306', 'Vrácena', 'A', 'DPP', NULL, 'Aktivní', '2023-01-13 16:56:57', '2023-01-13 16:56:57');
