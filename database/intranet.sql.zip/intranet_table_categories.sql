
-- --------------------------------------------------------

--
-- Struktura tabulky `categories`
--

CREATE TABLE `categories` (
  `id` bigint UNSIGNED NOT NULL,
  `category_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `folder_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_icon` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Vypisuji data pro tabulku `categories`
--

INSERT INTO `categories` (`id`, `category_name`, `folder_name`, `category_icon`, `color`) VALUES
(1, 'Akreditační', 'akreditacni', 'akreditacni.png', 'blue'),
(2, 'Ošetřovatelské', 'osetrovatelske', 'osetrovatelske.png', 'pink'),
(3, 'Léčebné', 'lecebne', 'lecebne.png', 'red'),
(4, 'Speciální', 'specialni', 'specialni.png', 'muted'),
(5, 'Operační', 'operacni', 'operacni.png', 'lime'),
(6, 'Anesteziologické', 'anesteziologicke', 'anesteziologicke.png', 'purple'),
(7, 'RDG', 'rdg', 'rdg.png', 'yellow'),
(8, 'Rehabilitační', 'rehabilitacni', 'rehabilitacni.png', 'green'),
(9, 'OPL', 'opl', 'opl.png', 'teal'),
(10, 'OKB', 'okb', 'okb.png', 'puple'),
(11, 'Logopedické', 'logopedicke', 'logopedicke.png', 'cyan'),
(12, 'Legislativní', 'legislativni', 'legislativni.png', 'orange');
