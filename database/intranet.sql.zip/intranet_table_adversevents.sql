
-- --------------------------------------------------------

--
-- Struktura tabulky `adversevents`
--

CREATE TABLE `adversevents` (
  `id` bigint UNSIGNED NOT NULL,
  `department_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `misto` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `datum_cas` date NOT NULL,
  `cas` time NOT NULL,
  `spec_druh` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `jinydoplnek` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pracovnik` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `svedek` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pacient` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `datumnaroz` date DEFAULT NULL,
  `chorobopis` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `udalost` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reseni` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opatreni` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `informovan` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pricina` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jina_pricina` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stav_pacienta` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lokalizace` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `druh_zraneni` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preventivni_opatreni` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zhodnoceni_stavu` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `datum` date DEFAULT NULL,
  `jmeno_lekare` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vyvoj` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `upresneni` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('Rozpracováno','Odesláno','Dokončeno') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `resitel` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vyjadreni` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resitel1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vyjadreni1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resitel2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vyjadreni2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Vypisuji data pro tabulku `adversevents`
--

INSERT INTO `adversevents` (`id`, `department_id`, `misto`, `datum_cas`, `cas`, `spec_druh`, `jinydoplnek`, `pracovnik`, `svedek`, `pacient`, `datumnaroz`, `chorobopis`, `udalost`, `reseni`, `opatreni`, `informovan`, `pricina`, `jina_pricina`, `stav_pacienta`, `lokalizace`, `druh_zraneni`, `preventivni_opatreni`, `zhodnoceni_stavu`, `datum`, `jmeno_lekare`, `vyvoj`, `upresneni`, `status`, `resitel`, `vyjadreni`, `resitel1`, `vyjadreni1`, `resitel2`, `vyjadreni2`, `created_at`, `updated_at`) VALUES
(1, '29', 'Rerum in molestiae i', '2023-01-15', '20:03:00', 'Pád', NULL, 'Sit deserunt obcaeca', 'Nesciunt exercitati', 'Dolores recusandae', '1994-07-26', 'Ducimus a dolor sit', 'Consectetur dolore p', 'Impedit aut incidun', 'Aut consequat Exerc', 'Fuga Velit autem in', 'pád z lůžka bez postranic', NULL, 'zmatený/á', 'horní končetiny', 'Tržná rána', 'dsfdsf', 'sdfdsfdsf', '2023-01-15', 'sdfdsfdsf', 'jiný', 'sdfdsfsdf', 'Dokončeno', NULL, NULL, NULL, NULL, NULL, NULL, '2023-01-15 19:03:20', '2023-01-15 19:03:20'),
(2, '12', 'Aliqua Magnam id si', '1993-10-13', '15:45:00', 'Klinický výkon', NULL, 'Occaecat velit eiusm', 'In ducimus veniam', 'Dolorem maxime atque', '1970-08-07', 'Aut pariatur Conseq', 'Minima eius dolorem', 'Amet fuga Ut conse', 'Doloribus odio quos', 'Non aliquid delectus', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'žádný', NULL, 'Rozpracováno', NULL, NULL, NULL, NULL, NULL, NULL, '2023-01-16 07:22:05', '2023-01-16 19:42:42'),
(3, '31', 'Et eum ea ex possimu', '1982-03-24', '04:26:00', 'Transfuze, krevní deriváty', NULL, 'Tempor facilis nesci', 'In modi et rem cupid', 'Enim perferendis cor', '2009-07-24', 'Fuga Laudantium qu', 'In quibusdam volupta', 'Qui veniam id adipi', 'Dolorem dolor est c', 'Consequat Sed magna', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'žádný', NULL, 'Rozpracováno', NULL, NULL, NULL, NULL, NULL, NULL, '2023-01-16 07:22:12', '2023-01-16 07:22:12'),
(4, '28', 'Unde consectetur as', '2015-09-09', '16:15:00', 'Svévolný odchod pacienta', NULL, 'Vel irure iste quide', 'Quo sint quas ad ne', 'Labore asperiores di', '2007-07-07', 'Ut autem illum expe', 'Ut dolor exercitatio', 'Dolor qui voluptates', 'Soluta ut illum nul', 'Et cupidatat labore', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'žádný', NULL, 'Odesláno', NULL, NULL, NULL, NULL, NULL, NULL, '2023-01-16 07:22:19', '2023-01-16 07:22:19'),
(5, '22', 'Dignissimos quae vel', '2017-08-14', '00:47:00', 'Nežádoucí účinek léčiva', NULL, 'Quaerat assumenda nu', 'Praesentium fugiat o', 'Sint animi eos qua', '1998-10-07', 'Ullamco quia modi do', 'Saepe deserunt excep', 'Illo adipisicing asp', 'Consequatur anim aut', 'Pariatur In vitae i', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'žádný', NULL, 'Dokončeno', NULL, NULL, NULL, NULL, NULL, NULL, '2023-01-16 07:22:23', '2023-01-16 07:22:23'),
(6, '23', 'Sunt cupiditate lab', '2019-03-04', '12:22:00', 'Problém s technikou nebo vybavením', NULL, 'Ducimus itaque dolo', 'Enim vero in ab tene', 'Nihil dolore ut occa', '2017-09-18', 'Officia id incididun', 'Nam ad enim sit tota', 'Sed eos ea veritatis', 'Tempore temporibus', 'Elit voluptatem mod', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'žádný', NULL, 'Rozpracováno', NULL, NULL, NULL, NULL, NULL, NULL, '2023-01-16 07:22:26', '2023-01-16 07:22:26'),
(7, '26', 'Enim nisi dolorem mo', '1977-04-10', '13:32:00', 'Pád', NULL, 'Architecto sed exped', 'Est aliquam molestia', 'Hic amet omnis et p', '2004-11-28', 'Aspernatur libero vo', 'Repudiandae voluptat', 'Odio tempore et lab', 'Incidunt eos ab exp', 'Perferendis sit volu', 'jiný důvod pádu', NULL, 'orientovaný/á', 'pánev', 'Hematom (lehké zranění)', NULL, NULL, NULL, NULL, 'jiný', 'sdfdsfsdf', 'Dokončeno', NULL, NULL, NULL, NULL, NULL, NULL, '2023-01-16 07:22:44', '2023-01-16 07:22:44'),
(8, '10', 'Voluptatem providen', '1988-11-15', '03:21:00', 'Pád', NULL, 'Ea autem sunt magna', 'Adipisicing esse fac', 'Elit quis esse aliq', '1987-11-28', 'Ad placeat consequa', 'Repellendus Nobis l', 'Error quis soluta re', 'Repudiandae dolores', 'Quaerat explicabo H', 'pád z lůžka s postranicemi', NULL, 'bezvědomí', 'ruka', 'Jiné SZ (střední zranění)', NULL, NULL, NULL, NULL, 'překlad', NULL, 'Dokončeno', NULL, NULL, NULL, NULL, NULL, NULL, '2023-01-16 07:23:14', '2023-01-16 07:23:14'),
(9, '24', 'Cillum sapiente elig', '1986-12-14', '19:20:00', 'Pád', NULL, 'Fugit facilis sunt', 'Ducimus sunt fugiat', 'Quidem laboris conse', '1985-08-09', 'Anim voluptatum numq', 'Quasi culpa quos la', 'Modi ipsum quo duis', 'Soluta irure dolore', 'Nisi sed cumque volu', 'vstávání z lůžka', NULL, 'orientovaný/á', 'dolní končetiny', 'Komoce mozku (těžké zranění)', NULL, NULL, NULL, NULL, 'překlad', NULL, 'Odesláno', NULL, NULL, NULL, NULL, NULL, NULL, '2023-01-16 07:23:22', '2023-01-16 07:23:22'),
(10, '3', 'Illum labore magna', '1989-09-16', '16:41:00', 'Nehody a neočekávaná zranění', NULL, 'Quis quo quasi nisi', 'Voluptates ipsum dol', 'Qui animi dolores l', '2013-01-22', 'Est sequi quia nece', 'Consequatur quam co', 'Doloribus corrupti', 'Nihil in assumenda a', 'Doloremque aspernatu', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'žádný', NULL, 'Dokončeno', NULL, NULL, NULL, NULL, NULL, NULL, '2023-01-16 07:23:27', '2023-01-16 07:23:27'),
(11, '31', 'Odit est deserunt la', '1978-12-05', '00:00:00', 'Nežádoucí účinek léčiva', NULL, 'Minus enim atque in', 'Nisi vitae voluptate', 'Nihil praesentium nu', '1978-11-14', 'Officia aut tempore', 'Harum saepe fuga Ma', 'Cumque elit nobis d', 'Qui ex neque quasi q', 'Quia elit hic excep', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'žádný', NULL, 'Rozpracováno', NULL, NULL, NULL, NULL, NULL, NULL, '2023-01-16 07:23:33', '2023-01-16 07:23:33'),
(12, '10', 'Ullam sint voluptate', '2000-08-26', '12:30:00', 'Medikace', NULL, 'Voluptates ut amet', 'Qui ut iusto vero bl', 'Totam quasi libero o', '1996-11-22', 'Adipisci consectetur', 'Velit dolor ex dolo', 'Necessitatibus error', 'Aut odit duis aut mo', 'Non fugiat tempor eu', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'žádný', NULL, 'Odesláno', NULL, NULL, NULL, NULL, NULL, NULL, '2023-01-16 07:23:41', '2023-01-16 07:23:41'),
(13, '11', 'Molestiae qui verita', '1993-12-22', '09:49:00', 'Problém s technikou nebo vybavením', NULL, 'Ipsa in laborum Ve', 'Lorem vel ex facilis', 'Mollitia exercitatio', '1991-06-26', 'Ea sunt omnis velit', 'Commodi corporis dol', 'Dolorem eum dolor to', 'Commodo fuga Quam r', 'Et impedit ea rerum', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'žádný', NULL, 'Rozpracováno', NULL, NULL, NULL, NULL, NULL, NULL, '2023-01-16 07:23:46', '2023-01-16 07:23:46'),
(14, '6', 'Esse quas aliquip se', '1995-08-24', '15:05:00', 'Nehody a neočekávaná zranění', NULL, 'Itaque aliquam fugia', 'Ullam obcaecati in c', 'Nostrum veniam exer', '2015-05-13', 'Occaecat sit cumque', 'Amet corporis moles', 'Aliquid sequi dignis', 'Sit eveniet hic mo', 'Incididunt aut assum', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'žádný', NULL, 'Odesláno', NULL, NULL, NULL, NULL, NULL, NULL, '2023-01-16 07:23:54', '2023-01-16 07:23:54');
