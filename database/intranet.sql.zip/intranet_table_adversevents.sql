
-- --------------------------------------------------------

--
-- Struktura tabulky `adversevents`
--

CREATE TABLE `adversevents` (
  `id` bigint UNSIGNED NOT NULL,
  `department_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `misto` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `datum_cas` date NOT NULL,
  `cas` time NOT NULL,
  `spec_druh` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jinydoplnek` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pracovnik` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `svedek` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pacient` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `datumnaroz` date DEFAULT NULL,
  `chorobopis` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `udalost` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reseni` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opatreni` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `informovan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pricina` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jina_pricina` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stav_pacienta` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lokalizace` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `druh_zraneni` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preventivni_opatreni` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zhodnoceni_stavu` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `datum` date DEFAULT NULL,
  `jmeno_lekare` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vyvoj` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `upresneni` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('Rozpracováno','Odesláno','Dokončeno') COLLATE utf8mb4_unicode_ci NOT NULL,
  `resitel` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vyjadreni` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resitel1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vyjadreni1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resitel2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vyjadreni2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
