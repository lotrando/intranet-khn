
-- --------------------------------------------------------

--
-- Struktura tabulky `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Vypisuji data pro tabulku `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(106, '2014_10_12_000000_create_users_table', 1),
(107, '2014_10_12_100000_create_password_resets_table', 1),
(108, '2014_10_12_200000_add_two_factor_columns_to_users_table', 1),
(109, '2019_08_19_000000_create_failed_jobs_table', 1),
(110, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(111, '2022_10_31_054214_create_employees_table', 1),
(112, '2022_10_31_080147_create_departments_table', 1),
(113, '2022_11_02_121758_create_jobs_table', 1),
(114, '2022_11_14_070835_create_toners_table', 1),
(115, '2022_11_14_075215_create_evidence_table', 1),
(116, '2022_11_14_080256_create_printers_table', 1),
(117, '2022_11_22_184739_create_trainings_table', 1),
(118, '2022_11_22_185011_create_slides_table', 1),
(119, '2022_11_23_070339_create_attendances_table', 1),
(121, '2022_12_15_052046_create_adversevents_table', 1),
(130, '2023_01_07_200629_create_documents_table', 3),
(131, '2023_01_07_203151_create_addons_table', 3),
(132, '2022_12_14_084811_create_categories_table', 4);
