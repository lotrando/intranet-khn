
-- --------------------------------------------------------

--
-- Struktura tabulky `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `job_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Vypisuji data pro tabulku `jobs`
--

INSERT INTO `jobs` (`id`, `job_title`) VALUES
(1, 'asistentka ředitele'),
(2, 'dohlížející osoba pro radiační činnost'),
(3, 'dokumentační pracovnice'),
(4, 'ekonomický náměstek'),
(5, 'ergoterapeut'),
(6, 'farmaceut'),
(7, 'farmaceutický asistent'),
(8, 'finanční účetní'),
(9, 'fyzioterapeut'),
(10, 'klinický logoped'),
(11, 'kuchař'),
(12, 'lékař'),
(13, 'manažer kvality, ústavní hygienik'),
(14, 'manažer léčby ran'),
(15, 'manažer vztahů s veřejností'),
(16, 'mzdová účetní'),
(17, 'náměstek pro ošetřovatelskou péči'),
(18, 'nezadáno'),
(19, 'nutriční terapeut'),
(20, 'ošetřovatel'),
(21, 'ošetřovatelka'),
(22, 'pokladní'),
(23, 'pomocnice na úklid'),
(24, 'pomocný pracovník'),
(25, 'pracovnice podatelny'),
(26, 'pracovnice spisovny/archivu'),
(27, 'pracovník rozvozu stravy'),
(28, 'pracovník údržby'),
(29, 'praktická sestra'),
(30, 'předseda dozorčí rady'),
(31, 'primář'),
(32, 'prodavačka'),
(33, 'provozně-technický náměstek'),
(34, 'provozní pracovník, vedoucí recepce'),
(35, 'radiologický asistent'),
(36, 'radiologický asistent, technik BOZP'),
(37, 'recepční'),
(38, 'ředitel, předseda představenstva'),
(39, 'revizní technik, energetik'),
(40, 'řidič'),
(41, 'sanitář'),
(42, 'sanitářka'),
(43, 'šéfkuchař'),
(44, 'skladnice'),
(45, 'správce počítačové sítě'),
(46, 'správce zdravotnických prostředků, metrolog'),
(47, 'staniční sestra'),
(48, 'technik IT'),
(49, 'tisková mluvčí'),
(50, 'učitel'),
(51, 'učitelka'),
(52, 'vedoucí CPM'),
(53, 'vedoucí farmaceut'),
(54, 'vedoucí finanční účtárny'),
(55, 'vedoucí fyzioterapeut'),
(56, 'vedoucí IT'),
(57, 'vedoucí kantýny'),
(58, 'vedoucí lékař'),
(59, 'vedoucí personálního a mzdového oddělení'),
(60, 'vedoucí radiologický asistent'),
(61, 'vedoucí stravovacího provozu'),
(62, 'vedoucí údržby'),
(63, 'vedoucí úklidu'),
(64, 'všeobecná sestra'),
(65, 'výkonová účetní'),
(66, 'vývojář, webmaster'),
(67, 'zástupce primáře'),
(68, 'zástupce stan. sestry'),
(69, 'zástupce vedoucího farmaceuta'),
(70, 'zdravotně sociální pracovnice'),
(71, 'zdravotní laborant'),
(72, 'nezařazeno');
