
-- --------------------------------------------------------

--
-- Struktura tabulky `documents`
--

CREATE TABLE `documents` (
  `id` bigint UNSIGNED NOT NULL,
  `category_id` bigint NOT NULL,
  `accordion_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accordion_group` int DEFAULT NULL,
  `position` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revision` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unique_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('Rozpracováno','Schváleno') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Vypisuji data pro tabulku `documents`
--

INSERT INTO `documents` (`id`, `category_id`, `accordion_name`, `accordion_group`, `position`, `name`, `description`, `revision`, `file`, `unique_code`, `status`, `created_at`, `updated_at`) VALUES
(1, 3, 'Standard léčebného postupu', NULL, 1, 'Standard léčebného postupu', 'Akutní koronární syndromy', '5', 'lecebne_standard_lec-01.pdf', 'lec-01', 'Schváleno', '2023-01-13 21:02:48', '2023-01-13 21:02:48'),
(2, 3, 'Standard léčebného postupu', NULL, 2, 'Standard léčebného postupu', 'ATB profylaxe u operovaných pacientů', '3', 'lecebne_standard_lec-02.pdf', 'lec-02', 'Schváleno', '2023-01-13 21:16:31', '2023-01-13 21:16:31'),
(3, 3, 'Standard léčebného postupu', NULL, 3, 'Standard léčebného postupu', 'Crohnova choroba', '5', 'lecebne_standard_lec-03.pdf', 'lec-03', 'Schváleno', '2023-01-13 21:17:50', '2023-01-13 21:17:50'),
(4, 3, 'Standard léčebného postupu', NULL, 4, 'Standard léčebného postupu', 'Demence', '6', 'lecebne_standard_lec-04.pdf', 'lec-04', 'Schváleno', '2023-01-13 21:28:06', '2023-01-13 21:28:06'),
(5, 3, 'Standard léčebného postupu', NULL, 5, 'Standard léčebného postupu', 'Diabetes mellitus', '4', 'lecebne_standard_lec-05.pdf', 'lec-05', 'Schváleno', '2023-01-13 21:33:31', '2023-01-13 21:33:31'),
(6, 3, 'Standard léčebného postupu', NULL, 6, 'Standard léčebného postupu', 'u pacientů s diagnózou Epilepsie', '6', 'lecebne_standard_lec-06.pdf', 'lec-06', 'Schváleno', '2023-01-13 21:34:48', '2023-01-13 21:34:48'),
(7, 3, 'Standard léčebného postupu', NULL, 7, 'Standard léčebného postupu', 'Febrilie nejasné etiologie', '4', 'lecebne_standard_lec-07.pdf', 'lec-07', 'Schváleno', '2023-01-13 21:36:13', '2023-01-13 21:36:13'),
(8, 3, 'Standard léčebného postupu', NULL, 8, 'Standard léčebného postupu', 'Chronická bolest u degenerativních onemocnění páteře', '5', 'lecebne_standard_lec-08.pdf', 'lec-08', 'Schváleno', '2023-01-13 21:38:25', '2023-01-13 21:38:25'),
(9, 3, 'Standard léčebného postupu', NULL, 9, 'Standard léčebného postupu', 'Soubor indikačních kritérií a postupů oddělení chirurgie páteře', '6', 'lecebne_standard_lec-09.pdf', 'lec-09', 'Schváleno', '2023-01-13 21:39:52', '2023-01-13 21:39:52'),
(10, 3, 'Standard léčebného postupu', NULL, 10, 'Standard léčebného postupu', 'Indikace zátěžových vyšetření', '5', 'lecebne_standard_lec-10.pdf', 'lec-10', 'Schváleno', '2023-01-13 21:40:42', '2023-01-13 21:40:42'),
(11, 3, 'Standard léčebného postupu', NULL, 11, 'Standard léčebného postupu', 'Ischemická cévní mozková příhoda', '6', 'lecebne_standard_lec-11.pdf', 'lec-11', 'Schváleno', '2023-01-13 21:41:31', '2023-01-13 21:41:31'),
(12, 3, 'Standard léčebného postupu', NULL, 12, 'Standard léčebného postupu', 'Myokarditida', '5', 'lecebne_standard_lec-12.pdf', 'lec-12', 'Schváleno', '2023-01-13 21:42:52', '2023-01-13 21:42:52'),
(13, 3, 'Standard léčebného postupu', NULL, 13, 'Standard léčebného postupu', 'Myopatie', '5', 'lecebne_standard_lec-13.pdf', 'lec-13', 'Schváleno', '2023-01-13 21:49:16', '2023-01-13 21:49:16'),
(14, 3, 'Standard léčebného postupu', NULL, 14, 'Standard léčebného postupu', 'Parkinsonova choroba', '6', 'lecebne_standard_lec-14.pdf', 'lec-14', 'Schváleno', '2023-01-13 21:49:58', '2023-01-13 21:49:58'),
(15, 3, 'Standard léčebného postupu', NULL, 15, 'Standard léčebného postupu', 'Polyneuropathie', '6', 'lecebne_standard_lec-15.pdf', 'lec-15', 'Schváleno', '2023-01-13 21:51:20', '2023-01-13 21:51:20'),
(16, 3, 'Standard léčebného postupu', NULL, 16, 'Standard léčebného postupu', 'Předoperační vyšetření kardiaka před nekardiochirurgickými výkony', '5', 'lecebne_standard_lec-16.pdf', 'lec-16', 'Schváleno', '2023-01-13 21:52:04', '2023-01-13 21:52:04'),
(17, 3, 'Standard léčebného postupu', NULL, 17, 'Standard léčebného postupu', 'Roztroušená skleróza', '6', 'lecebne_standard_lec-17.pdf', 'lec-17', 'Schváleno', '2023-01-13 21:53:04', '2023-01-13 21:53:04'),
(18, 3, 'Standard léčebného postupu', NULL, 18, 'Standard léčebného postupu', 'Soubor indikačních kritérií a postupů oddělení ortopedie', '2', 'lecebne_standard_lec-18.pdf', 'lec-18', 'Schváleno', '2023-01-13 21:54:14', '2023-01-13 21:54:14'),
(19, 3, 'Standard léčebného postupu', NULL, 19, 'Standard léčebného postupu', 'Standard léčebného postupu Soubor postupů při ošetření infikované nebo potenciálně infikované TEP', '2', 'lecebne_standard_lec-19.pdf', 'lec-19', 'Schváleno', '2023-01-13 21:55:05', '2023-01-13 21:55:05'),
(20, 3, 'Standard léčebného postupu', NULL, 20, 'Standard léčebného postupu', 'Vředová choroba gastroduodena', '5', 'lecebne_standard_lec-20.pdf', 'lec-20', 'Schváleno', '2023-01-13 21:56:19', '2023-01-13 21:56:19'),
(21, 1, '1. Správná identifikace pacientů', 1, 1, '1. Správná identifikace pacientů', 'Bezpečnostní cíle - Správná identifikace pacientů', '3', 'akreditacni_standard_akr-01.pdf', 'akr-01', 'Schváleno', '2023-01-13 22:00:10', '2023-01-13 22:00:10'),
(22, 1, '2. Efektivní komunikace', 1, 1, '2. Efektivní komunikace', 'Bezpečnostní cíle - Efektivní komunikace', '7', 'akreditacni_standard_akr-02.pdf', 'akr-02', 'Schváleno', '2023-01-13 22:02:08', '2023-01-13 22:02:08'),
(23, 1, '2. Zvýšení bezpečí u rizikových léků', 1, 1, '3. Zvýšení bezpečí u rizikových léků', 'Bezpečnostní cíle - Zvýšení bezpečí u rizikových léků', '3', 'akreditacni_standard_akr-03.pdf', 'akr-03', 'Schváleno', '2023-01-13 22:03:22', '2023-01-13 22:03:22');
