
-- --------------------------------------------------------

--
-- Struktura tabulky `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `personal_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Vypisuji data pro tabulku `users`
--

INSERT INTO `users` (`id`, `personal_number`, `name`, `email`, `email_verified_at`, `password`, `two_factor_secret`, `two_factor_recovery_codes`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, '61624', 'doc. Ladislav Šrámek', 'pechova.vojtech@example.com', '2023-01-11 16:48:16', '$2y$10$BAdJ9fLW3fmK.nnCZkzdSetDf1X1ZSFqVQPTvNwEga4sPszaV0zEO', NULL, NULL, 'bic2csQ9rBpTaQaJnDajKrvWVxUQiRU0WpATjBvYa71ORYktviBXViPdZnor', '2023-01-11 16:48:17', '2023-01-11 16:48:17'),
(2, '63890', 'Robert Mareš', 'wkorinkova@example.org', '2023-01-11 16:48:16', '$2y$10$nXUF3X/w8st1QSu4XhSdeukcq21YIxTK8TXd3wB/KmV.Hnb/aRyVO', NULL, NULL, 'OdDnHZjYSGyNupqKad5NDDwUXmathCf5tLqymPvUrerB5uF5NsfGNV5seQnD', '2023-01-11 16:48:17', '2023-01-11 16:48:17'),
(3, '62392', 'MVDr. Iva Smejkalová', 'kamil.pech@example.net', '2023-01-11 16:48:16', '$2y$10$G0JkMwqpMzY9PW07AMUA.e9do4e1Y2lzs59rUmCZ.voM6UjfUUHXa', NULL, NULL, 'uxE8zutIs6OAmj0l7oMs4yqEZTFe7XIsqr1reeOxIsErmAxMTJdL0xS3FDwh', '2023-01-11 16:48:17', '2023-01-11 16:48:17'),
(4, '61387', 'Lubomír Kuba', 'miloslav.janeckova@example.net', '2023-01-11 16:48:16', '$2y$10$xeDlaon1Bzc4tZx6H1OdN.2t38s8eVH.rwo5uL4FRIU1MEO0q8a2m', NULL, NULL, 'CbSinaSckMYa4O37awStAaP46pN36h2Nkr6ZQbciQ5j09aB8WKvjiWP7VDMK', '2023-01-11 16:48:17', '2023-01-11 16:48:17'),
(5, '62646', 'Mgr. Miroslav Špaček', 'hfantova@example.net', '2023-01-11 16:48:16', '$2y$10$3eTuNvBlVbsBcn6xbvNVYuA2JeUfONMF2EO7nsg2Ly0/CH2GYACNu', NULL, NULL, 'wuIAQHB7zd6RtCrNoMYypMZw9kLkDuqzxwrYL4mVqd5QYObmZiXEbJR8FXPj', '2023-01-11 16:48:17', '2023-01-11 16:48:17'),
(6, '62041', 'Denisa Brožková', 'mheger@example.org', '2023-01-11 16:48:16', '$2y$10$bZ4NvOkPfmQuZBQQyBXBj.sdeUUP1KBPBn9qCjD3hjOSG8EmJemFa', NULL, NULL, 'srrW0W8wQBPeNehMCMmhP4ImPkhUqX4choqs5QDzmmPILL3AwxoXrrcJERKt', '2023-01-11 16:48:17', '2023-01-11 16:48:17'),
(7, '64589', 'Vlastimil Seidl', 'pavlicova.barbora@example.net', '2023-01-11 16:48:16', '$2y$10$cIZn342f6.J4d/Y9bhbtc.frykPcye7UMi4va5TtNgoetDfI0EWAi', NULL, NULL, 'jbBnNTde9PICs64lW7CFb92fns1iT5LULg4iEGV8hvap8wtElP0KGkDo5voG', '2023-01-11 16:48:17', '2023-01-11 16:48:17'),
(8, '61199', 'PhDr. Ilona Kopečný', 'jakoubek.ivana@example.com', '2023-01-11 16:48:16', '$2y$10$LHGzVLpy/G9kAezVWgAyH.w4kZJM4sDCnTWicSCsVJwhueLR/EXkC', NULL, NULL, 'QBVSNpIZATAjovUq9Ud63FpDOisVK4B0qQINS2C3ZGzYoGDbnElIAIuFtxNL', '2023-01-11 16:48:17', '2023-01-11 16:48:17'),
(9, '64220', 'Vítězslav Studený', 'aprokop@example.net', '2023-01-11 16:48:16', '$2y$10$TXAjVT9k./.H4KjXoNAcn.ljLPiSjKS0B.vlGoGjEiJXFvNWX3CJG', NULL, NULL, 'Q84bE3b76njnJpTH1hee9690itatngELvYKuDNtYqpfuwZ72Y4EhZd2C0J3e', '2023-01-11 16:48:17', '2023-01-11 16:48:17'),
(10, '62457', 'PhDr. Jan Kuča', 'milena93@example.net', '2023-01-11 16:48:16', '$2y$10$y.1Fr4LcccsAuc2CCAp9seh5PonzrjwBcBDlKqaIaO4r0eYvvow3W', NULL, NULL, 'uKtD3jRcmQagjEDZs2oF9PpRq14SsqwMna9HjdAGFR5U2lai6N50iFFPsfDC', '2023-01-11 16:48:17', '2023-01-11 16:48:17'),
(11, '61625', 'Karleigh Becker', 'klika@khn.cz', NULL, '$2y$10$HZ53JhT7D0sw7B7igovwbe9/KCAZQK4I7KrHKz6pZcgGFLWzHg2MO', NULL, NULL, '3xVq6ENEC2dFbORL0QDjjrNTgGFDh9CB1OaN64hWVcfe2S0mOEG6ByNpL16R', '2023-01-11 18:53:36', '2023-01-11 18:53:36'),
(12, '63882', 'Anna Seidlová', 'mbalogova@example.org', '2023-01-13 16:56:57', '$2y$10$ihu2uS/uhaS01vFcu8M.6eN5ElPL//0lTNnPybHJWDbVuNOGbWvfe', NULL, NULL, 'jSCn8DxL6F6HZFbc37QMtjBOtiWFUr5RuuHEw0DVZUbCS6s2vqM58fO2ZjXy', '2023-01-13 16:56:57', '2023-01-13 16:56:57'),
(13, '64832', 'Marta Jílková', 'cibulkova.tomas@example.net', '2023-01-13 16:56:57', '$2y$10$43kzxF1NKZ/bu2BgUlG5D.I0JYRdvKu6v2ZyF83TkJBKh5nqeUCLW', NULL, NULL, 'rhlXHVt9qY9OsQA9Q8q4CRdFYxXxmbc5kliamjZKwMG5crFPZwTB1b2AE3XH', '2023-01-13 16:56:57', '2023-01-13 16:56:57'),
(14, '62297', 'Vladimíra Bradová', 'ncahova@example.org', '2023-01-13 16:56:57', '$2y$10$lU2Pubr/W60AJ.rFRlM0l.8DHV1vBszqcNyoGqHjbIdGEvPIEWUZS', NULL, NULL, 'CuPFejVxGLKnbWf4cNf5kauzdYDdEMtGwTQ4eXfcRokoZG38HmYA45ePlZLa', '2023-01-13 16:56:57', '2023-01-13 16:56:57'),
(15, '62572', 'Luděk Vinš', 'kralova.petra@example.org', '2023-01-13 16:56:57', '$2y$10$y26B2S4dnvMyc9fvmWTI8e.Cwh5EXoEbBtT6FgPjqhAaKaQaWmLby', NULL, NULL, 'PrKbCRRBez2zlQzHgYCohzw6Rxty3ZQy618N8V3fZyZTDetpigImZE0MvFFl', '2023-01-13 16:56:57', '2023-01-13 16:56:57'),
(16, '61272', 'Ing. Jaroslava Lacinová', 'vasyl85@example.org', '2023-01-13 16:56:57', '$2y$10$s6.M2gdec4c.l8U8Ay0bWuM6Rkdy6KukFJXINbVZRnXu0AdM2Ubtu', NULL, NULL, 'DoX12JZua6or0HqRo5JaZICQMbnSKusa8rgEBVsCTyQEaO44KxuyACfKVzhh', '2023-01-13 16:56:57', '2023-01-13 16:56:57'),
(17, '61958', 'Vlastimil Coufal', 'dominik71@example.org', '2023-01-13 16:56:57', '$2y$10$QmirZntDQuNtYHBkdXgxGOoyWeSlYKTsBCFDkqAQYyQEVbMck7D8a', NULL, NULL, 'hZotkV7WQQEHfadFXpQ0HgUcxErzy6LUmWjeVYZgsQ5D3wCqavaqKdhwSgiz', '2023-01-13 16:56:57', '2023-01-13 16:56:57'),
(18, '64455', 'Mgr. Marcela Horáková', 'ugruber@example.org', '2023-01-13 16:56:57', '$2y$10$hd9l6gk0xz37bppf6bzgzecQcu5w8rQqTW9jl1Bl5DkA3lZ6AL87S', NULL, NULL, 'gmCKB1bEEvkOVJItygVdJQ3urhnModAsjRrkmvdXpZfVpI90cYgvCrYEoP3D', '2023-01-13 16:56:57', '2023-01-13 16:56:57'),
(19, '63190', 'Vlasta Sedláková', 'olga09@example.org', '2023-01-13 16:56:57', '$2y$10$lFyN4DHGQMpcxDYyWQn1y.W6.7acTDL6p3GImSaEMGkt7utY7iADC', NULL, NULL, 'hYoBpCzzd0aYF4oQPXAWfqrQbFNuaExzqNW9VvhUQxxi6xfZBj0TEuP9xbys', '2023-01-13 16:56:57', '2023-01-13 16:56:57'),
(20, '61735', 'Ing. Miroslava Kochová', 'jirina.grundzova@example.org', '2023-01-13 16:56:57', '$2y$10$Su3jTkLHPa2PflBPChbTSuIgoZbClBiIrtHbnYGz50lAujcWSAC4m', NULL, NULL, '63EfP8YWpO3yZYw0OBPvFWDOMixZgVjGF5k6qIsUT3UmbIkNj5WfMx7LIS0Z', '2023-01-13 16:56:57', '2023-01-13 16:56:57'),
(21, '63881', 'Anežka Melicharová', 'ipsenickova@example.com', '2023-01-13 16:56:57', '$2y$10$Y4KDV1Sll4YhalKynVpxNu0nQBIs92cYY6xV0Z96HK4TSt5N9X5kS', NULL, NULL, 'aaU0aket8hncus2N0G8VFRP7EmgQPdShm1XwQv9dROWkA9r79FTE2T1aZrez', '2023-01-13 16:56:57', '2023-01-13 16:56:57');
