
-- --------------------------------------------------------

--
-- Struktura tabulky `toners`
--

CREATE TABLE `toners` (
  `id` bigint UNSIGNED NOT NULL,
  `toner_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `toner_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `toner_size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `toner_price` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
